package com.mihprojects.denstercombat;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private double coins_var = 0;
	private double level = 0;
	private double booster_1 = 0;
	private double booster_2 = 0;
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private LinearLayout linear2;
	private CircleImageView coin;
	private Button booster1;
	private Button booster2;
	private LinearLayout linear7;
	private TextView coins;
	private LinearLayout linear3;
	private TextView lvl;
	private LinearLayout linear4;
	private ProgressBar lvlbar;
	private LinearLayout lbst1;
	private LinearLayout lbs2;
	private ImageView imageview1;
	private TextView xbst1;
	private ImageView imageview2;
	private TextView xbst2;
	
	private TimerTask tmr;
	private SharedPreferences saver;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll1 = findViewById(R.id.vscroll1);
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		coin = findViewById(R.id.coin);
		booster1 = findViewById(R.id.booster1);
		booster2 = findViewById(R.id.booster2);
		linear7 = findViewById(R.id.linear7);
		coins = findViewById(R.id.coins);
		linear3 = findViewById(R.id.linear3);
		lvl = findViewById(R.id.lvl);
		linear4 = findViewById(R.id.linear4);
		lvlbar = findViewById(R.id.lvlbar);
		lbst1 = findViewById(R.id.lbst1);
		lbs2 = findViewById(R.id.lbs2);
		imageview1 = findViewById(R.id.imageview1);
		xbst1 = findViewById(R.id.xbst1);
		imageview2 = findViewById(R.id.imageview2);
		xbst2 = findViewById(R.id.xbst2);
		saver = getSharedPreferences("storage", Activity.MODE_PRIVATE);
		
		coin.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				coin.setScaleX((float)(0.9d));
				coin.setScaleY((float)(0.9d));
				coins_var = coins_var + booster_1;
				_update();
				tmr = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								coin.setScaleX((float)(1));
								coin.setScaleY((float)(1));
							}
						});
					}
				};
				_timer.schedule(tmr, (int)(50));
			}
		});
		
		booster1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (coins_var > (booster_1 * 500)) {
					booster_1++;
					coins_var = coins_var - (booster_1 * 500);
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "❗У тебя нет столько DENSTER COIN'ов!");
				}
			}
		});
		
		booster2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (coins_var > (booster_2 * 250)) {
					booster_2++;
					coins_var = coins_var - (booster_1 * 250);
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "❗У тебя нет столько DENSTER COIN'ов!");
				}
			}
		});
	}
	
	private void initializeLogic() {
		if (saver.contains("level")) {
			level = Double.parseDouble(saver.getString("level", ""));
		}
		else {
			level = 1;
		}
		if (saver.contains("booster1")) {
			booster_1 = Double.parseDouble(saver.getString("booster1", ""));
		}
		else {
			booster_1 = 1;
		}
		if (saver.contains("booster2")) {
			booster_2 = Double.parseDouble(saver.getString("booster2", ""));
		}
		if (saver.contains("coins")) {
			coins_var = Double.parseDouble(saver.getString("coins", ""));
		}
		_update();
	}
	
	@Override
	public void onBackPressed() {
		finishAffinity();
	}
	public void _update() {
		coins.setText(String.valueOf((long)(coins_var)));
		lvlbar.setProgress((int)coins_var);
		lvl.setText("LEVEL ".concat(String.valueOf((long)(level))));
		booster1.setText("+ 1 DC к клику (".concat(String.valueOf((long)(booster_1 * 500)).concat(" DC)")));
		booster2.setText("+ 1 Автотап (".concat(String.valueOf((long)(booster_2 * 250)).concat(" DC)")));
		switch((int)level) {
			case ((int)1): {
				lvlbar.setMax((int)1000);
				coin.setImageResource(R.drawable.spr1);
				break;
			}
			case ((int)2): {
				lvlbar.setMax((int)10000);
				coin.setImageResource(R.drawable.spr2);
				break;
			}
			case ((int)3): {
				coin.setImageResource(R.drawable.dencoin3);
				lvlbar.setMax((int)25000);
				break;
			}
			case ((int)4): {
				coin.setImageResource(R.drawable.dencoin4);
				lvlbar.setMax((int)100000);
				break;
			}
			case ((int)5): {
				coin.setImageResource(R.drawable.dencoin5);
				lvlbar.setVisibility(View.INVISIBLE);
				lvl.setText("LEVEL MAX");
				break;
			}
		}
		if (coins_var > 999) {
			level = 2;
		}
		if (coins_var > 9999) {
			level = 3;
		}
		if (coins_var > 24999) {
			level = 4;
		}
		if (coins_var > 99999) {
			level = 5;
		}
		if (2 < booster_1) {
			lbst1.setVisibility(View.VISIBLE);
			xbst1.setText("x".concat(String.valueOf((long)(booster_1))));
		}
		else {
			xbst1.setVisibility(View.GONE);
		}
		if (2 < booster_2) {
			lbs2.setVisibility(View.VISIBLE);
			xbst2.setText("x".concat(String.valueOf((long)(booster_2))));
		}
		else {
			lbs2.setVisibility(View.GONE);
		}
		saver.edit().putString("level", String.valueOf((long)(level))).commit();
		saver.edit().putString("coins", String.valueOf((long)(coins_var))).commit();
		saver.edit().putString("booster1", String.valueOf((long)(booster_1))).commit();
		saver.edit().putString("booster2", String.valueOf((long)(booster_2))).commit();
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}